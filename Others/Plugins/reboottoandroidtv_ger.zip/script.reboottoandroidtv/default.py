# -*- coding: utf-8 -*-
# check for script and reboot to nand if present
import xbmc, xbmcgui
import os
import subprocess

def main():
    nandscript = '/usr/sbin/rebootfromnand'
    
    if os.path.exists(nandscript):
        xbmcgui.Dialog().notification('Erfolg!', 'Neustart in Android TV!', xbmcgui.NOTIFICATION_INFO)
        subprocess.call([nandscript])
        xbmc.sleep(300)
        xbmc.executebuiltin('Reboot')
    else:
        xbmcgui.Dialog().notification('Fehler!', 'rebootfromnand nicht verfügbar!', xbmcgui.NOTIFICATION_ERROR)

if __name__ == '__main__':
    main()